<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-14 04:13:28 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_Pengambilanmatakuliah::action_ksm() ~ APPPATH\classes\controller\pengambilanmatakuliah.php [ 28 ]
2010-11-14 22:10:36 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_User::action_edit() ~ APPPATH\classes\controller\user.php [ 32 ]
2010-11-14 22:17:40 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_User::action_edit() ~ APPPATH\classes\controller\user.php [ 32 ]
2010-11-14 22:19:14 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_User::action_edit() ~ APPPATH\classes\controller\user.php [ 32 ]
2010-11-14 22:19:49 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_User::action_edit() ~ APPPATH\classes\controller\user.php [ 32 ]
2010-11-14 22:26:23 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_User::action_edit() ~ APPPATH\classes\controller\user.php [ 32 ]
2010-11-14 22:34:46 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_User::action_edit() ~ APPPATH\classes\controller\user.php [ 32 ]
2010-11-14 22:35:19 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_User::action_edit() ~ APPPATH\classes\controller\user.php [ 32 ]