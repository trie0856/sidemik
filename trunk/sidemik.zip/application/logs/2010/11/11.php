<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-11 10:08:36 --- ERROR: ReflectionException [ -1 ]: Class controller_front does not exist ~ SYSPATH\classes\kohana\request.php [ 1094 ]
2010-11-11 17:14:07 --- ERROR: ReflectionException [ -1 ]: Class controller_front does not exist ~ SYSPATH\classes\kohana\request.php [ 1094 ]