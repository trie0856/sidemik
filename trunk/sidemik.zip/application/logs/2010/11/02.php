<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-02 05:31:07 --- ERROR: ReflectionException [ -1 ]: Class controller_sidemik does not exist ~ SYSPATH\classes\kohana\request.php [ 1094 ]
2010-11-02 05:45:30 --- ERROR: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH\views\template.php [ 9 ]
2010-11-02 05:46:00 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE ~ APPPATH\classes\controller\welcome.php [ 8 ]