<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-13 02:17:56 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_Pengambilanmatakuliah::action_ambil() ~ APPPATH\classes\controller\pengambilanmatakuliah.php [ 17 ]
2010-11-13 02:21:16 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_Pengambilanmatakuliah::action_ambil() ~ APPPATH\classes\controller\pengambilanmatakuliah.php [ 17 ]
2010-11-13 02:27:02 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_Pengambilanmatakuliah::action_ksm() ~ APPPATH\classes\controller\pengambilanmatakuliah.php [ 28 ]