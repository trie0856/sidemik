<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-15 00:03:55 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_User::action_edit() ~ APPPATH\classes\controller\user.php [ 32 ]
2010-11-15 00:39:42 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_User::action_edit() ~ APPPATH\classes\controller\user.php [ 32 ]