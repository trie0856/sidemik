<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-19 04:52:36 --- ERROR: Kohana_Exception [ 0 ]: The tanggal property does not exist in the Model_Mahasiswa class ~ MODPATH\orm\classes\kohana\orm.php [ 375 ]
2010-11-19 04:54:22 --- ERROR: Kohana_Exception [ 0 ]: The tanggal property does not exist in the Model_Mahasiswa class ~ MODPATH\orm\classes\kohana\orm.php [ 375 ]
2010-11-19 04:54:23 --- ERROR: Kohana_Exception [ 0 ]: The tanggal property does not exist in the Model_Mahasiswa class ~ MODPATH\orm\classes\kohana\orm.php [ 375 ]
2010-11-19 04:55:44 --- ERROR: Kohana_Exception [ 0 ]: The tanggal property does not exist in the Model_Mahasiswa class ~ MODPATH\orm\classes\kohana\orm.php [ 375 ]
2010-11-19 05:40:32 --- ERROR: ErrorException [ 1 ]: Class 'Model_Dosen' not found ~ APPPATH\classes\controller\dosen.php [ 27 ]
2010-11-19 06:25:15 --- ERROR: ErrorException [ 1 ]: Class 'Model_Dosen' not found ~ APPPATH\classes\controller\dosen.php [ 27 ]
2010-11-19 06:27:30 --- ERROR: ErrorException [ 8 ]: Undefined variable: nip ~ APPPATH\classes\controller\website.php [ 172 ]
2010-11-19 06:40:10 --- ERROR: ErrorException [ 8 ]: Undefined index: 05 ~ APPPATH\views\mahasiswa\profil.php [ 38 ]
2010-11-19 06:43:22 --- ERROR: ErrorException [ 8 ]: Undefined index: 02 ~ APPPATH\views\mahasiswa\profil.php [ 38 ]
2010-11-19 18:58:10 --- ERROR: ErrorException [ 8 ]: Undefined variable: select_role ~ APPPATH\classes\controller\user.php [ 51 ]
2010-11-19 18:59:57 --- ERROR: Database_Exception [ 1048 ]: Column 'user_id' cannot be null [ INSERT INTO `roles_users` (`user_id`, `role_id`) VALUES (NULL, '1') ] ~ MODPATH\database\classes\kohana\database\mysql.php [ 179 ]