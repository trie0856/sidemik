<h2>Statistik</h2>
<br />
<img style="margin-left: auto; margin-right: auto; display: block" src="http://chart.apis.google.com/chart?chxr=0,2004,2010&chxs=0,676767,11.5,0,lt,676767&chxtc=0,12&chxt=x,y&chs=600x300&cht=ls&chco=FF0000&chd=s:loux659&chdlp=t&chls=2&chma=|5,5&chm=B,EFEFEF,0,0,0,1&chtt=Jumlah+Mahasiswa+per+Tahun" width="600" height="300" alt="Jumlah Mahasiswa per Tahun" />