<h2>Informasi Mata Kuliah</h2>
<table>
    <tr>
        <td><?php echo 'Kode';?></td>
        <td><?php echo $matakuliah->kode;?></td>
    </tr>
    <tr>
        <td><?php echo 'Nama Mata Kuliah';?></td>
        <td><?php echo $matakuliah->nama;?></td>
    </tr>
    <tr>
        <td><?php echo 'Jumlah SKS'?></td>
        <td><?php echo $matakuliah->jumlah_sks;?></td>
    </tr>
    <tr>
        <td><?php echo 'Deskripsi'?></td>
        <td><?php echo $matakuliah->deskripsi;?></td>
    </tr>
    <tr>
        <td><?php echo 'Tingkat'?></td>
        <td><?php echo $matakuliah->tingkat;?></td>
    </tr>
    <tr>
        <td><?php echo 'Semester Buka'?></td>
        <td><?php echo $matakuliah->semester_buka;?></td>
    </tr>
</table>