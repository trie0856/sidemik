</div>
<div id="footer">
    Copyright &copy; 2010. Akademi Keperawatan Al-Hambra.
</div>
            </div>
        </div>
    </body>
</html>
