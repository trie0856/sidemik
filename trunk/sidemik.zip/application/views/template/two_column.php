<?php
include 'header.php';
include 'navigator.php';
?>
<div id="content_2column">
    <?php
    echo $content;
    ?>
</div>
<div class="clear"></div>
<?php include 'footer.php'?>