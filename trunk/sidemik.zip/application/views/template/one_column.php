<?php include 'header.php';?>
                <div id="content_1column">
                    <?php echo $content;?>
                </div>
                <div class="clear" />
<?php include 'footer.php';?>