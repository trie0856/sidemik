<?php defined('SYSPATH') or die('No direct script access.');

class Model_Matakuliah extends ORM
{
    protected $_primary_key = 'kode';
    protected $_table_name = 'matakuliah';
}