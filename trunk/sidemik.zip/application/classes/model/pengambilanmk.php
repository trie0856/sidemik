<?php defined('SYSPATH') or die('No direct script access.');

class Model_Pengambilanmk extends ORM
{
    protected $_table_name = 'pengambilan_mk';
}