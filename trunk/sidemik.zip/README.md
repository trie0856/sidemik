# Kohana PHP Framework, version 3.0 (dev)

This is the current development version of [Kohana](http://kohanaframework.org/).
