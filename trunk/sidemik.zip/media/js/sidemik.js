
// Konfirmasi untuk melakukan pengahapusan
function konfirmasi_hapus(){
    return confirm("Apakah Anda Yakin Menghapus?");
}