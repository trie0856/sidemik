# Modèle Vue Controleur

Modèle Vue Controleur (ou MVC) est un design pattern populaire visant à séparer les sources de données (Modèle) de la présentation (Vue) et de l'enchainement logique de traitement de la requête (Controleur).

Il rend plus facile le développement d'application modulaires et réutilisables.