Esta página lista las características de Kohana v3
