<?php defined('SYSPATH') or die('No direct script access.');

class ORM extends Kohana_ORM {}