# OAuth Usage

[!!] This is a stub. Please see [controller/oauth source](http://github.com/kohana/oauth/tree/206c20033e209f233c9e7dc72836bfb786bd7e34/classes/controller) for now. The methods [OAuth_Provider_Google::user_profile] and [OAuth_Provider_Twitter::update_status] no longer exist in the current git master branch.
