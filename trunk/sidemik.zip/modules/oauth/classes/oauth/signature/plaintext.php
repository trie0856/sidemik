<?php defined('SYSPATH') or die('No direct script access.');

class OAuth_Signature_PLAINTEXT extends Kohana_OAuth_Signature_PLAINTEXT {  }
