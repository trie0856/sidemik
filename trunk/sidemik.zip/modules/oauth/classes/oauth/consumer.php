<?php defined('SYSPATH') or die('No direct script access.');

class OAuth_Consumer extends Kohana_OAuth_Consumer {  }
