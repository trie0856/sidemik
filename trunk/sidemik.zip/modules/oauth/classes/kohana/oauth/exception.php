<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
 * OAuth Exception
 *
 * @package    Kohana/OAuth
 * @category   Exceptions
 * @author     Kohana Team
 * @copyright  (c) 2010 Kohana Team
 * @license    http://kohanaframework.org/license
 * @since      3.0.7
 */
class Kohana_OAuth_Exception extends Kohana_Exception {  }
