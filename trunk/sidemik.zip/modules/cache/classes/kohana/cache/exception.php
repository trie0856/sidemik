<?php defined('SYSPATH') or die('No direct script access.');

class Kohana_Cache_Exception extends Kohana_Exception {}